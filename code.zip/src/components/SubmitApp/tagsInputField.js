import React from 'react'
import { WithContext as ReactTags } from 'react-tag-input';

/**
* @author
* @function TagsInput
**/

const TagsInput = (props) => {
  return(
    <div>TagsInput</div>
   )

 }

export default TagsInput