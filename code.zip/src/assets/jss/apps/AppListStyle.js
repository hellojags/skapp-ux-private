const appListStyle = {
    listContain: {
        marginTop: '1rem',
        '@media only screen and (max-width: 575px)': {
            marginTop: 0
        },
    }
}
export default appListStyle